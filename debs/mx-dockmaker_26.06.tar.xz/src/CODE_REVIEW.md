# Code Review — mx-dockmaker

**Branch:** `master`, **Last commit:** `143241e Update Debian packaging metadata`
**Generated:** June 19, 2026

| Group | Items | Status |
|-------|-------|--------|
| A — Build & packaging infra | 1–3 | Done |
| B — Command invocation hardening | 4 | Done |
| E — Code quality cleanup | 5–7 | Done |
| F — Code style | 8–9 | Done |
| I — Trivial one-liners | 10–11 | Done |
| **Total** | **11** | **All done** |

---

### Group A — Build & packaging infra

Items that touch only CMakeLists.txt, debian/, build scripts — no C++ source changes.

1. [x] **`option(USE_CLANG ...)` declared twice in CMakeLists.txt** — Lines 26–31 and lines 72–78 both declare the same option with different implementations. The first sets `CMAKE_C_COMPILER` / `CMAKE_CXX_COMPILER` as CACHE FORCE (so project() picks them up). The second sets `CMAKE_CXX_COMPILER_ID` to `"Clang"` but skips `CMAKE_C_COMPILER`. This means `--clang` with GCC still active sets CXX=clang++ but leaves C=gcc — a mixed toolchain. One `option()` block is enough; merge the logic.

2. [x] **`-Wpedantic` and `-pedantic` are duplicate flags** — CMakeLists.txt:148–149 sets both flags. They are exact aliases on both GCC and Clang. Remove one.

3. [x] **`override_dh_auto_test` skips tests unconditionally** — `debian/rules:18–19` has an explicit skip with the comment "Skip tests as no test targets are defined." CMakeLists.txt has `ENABLE_TESTS` (off by default) with two test targets (`dockfileparser_test`, `deletion_test`). The override should pass `-DENABLE_TESTS=ON` to `dh_auto_configure` rather than overriding `dh_auto_test` to skip, so a future packager can toggle tests. Alternatively, keep the skip but update the comment to reflect the actual intent (tests are opt-in).

---

### Group B — Command invocation hardening

Items that make subprocess calls safer.

4. [x] **Shell-string interpolation of app.command in generated dock scripts** — `dockfilemanager.cpp:362` interpolates `app.command` directly into a shell command string without `escapeShellArg()`:
    ```cpp
    command = "--command " + app.command + " --icon " + escapeShellArg(iconPath);
    ```
    While `app.command` is user-entered, if it contains shell metacharacters (spaces, `;`, `$`, backticks), the generated dock script will misbehave or execute unintended commands. The fix is to wrap `app.command` in `escapeShellArg()`.

---

### Group E — Code quality cleanup

Items that reduce distraction when reading the codebase.

5. [x] **`PickLocation::button` is a public data member** — `picklocation.h:40` exposes `QString button` as public. Encapsulation is broken; return the value via a getter or make it private and add `getSelectedLocation()`.

6. [x] **Unused `DRAG_THRESHOLD` constant** — `icondragdrophandler.h:69` defines `static constexpr int DRAG_THRESHOLD = 10;` but the implementation uses `QApplication::startDragDistance()` instead (icondragdrophandler.cpp:94). The constant is dead code. Remove it.

7. [x] **`DockIconManager::getIconSearchPaths()` allocates a new `QStringList` on every call** — `dockiconmanager.cpp:266–269` constructs and returns a fresh list each time. This is called from `findFilesystemIcon` on every icon lookup. Cache the result as a static or member variable since the paths don't change at runtime.

---

### Group F — Code style

Purely cosmetic, safe to batch.

8. [x] **snake_case local variables in `mainwindow.cpp`** — `selected_dock` (lines 472, 802, 806, 810), `default_folder` (lines 933, 935, 936, 938), `f_info` (line 935) use snake_case instead of `camelCase` as specified in AGENTS.md. Rename to `selectedDock`, `defaultFolder`, `fileInfo`.

9. [x] **Missing `[[nodiscard]]` on const getters** — The following non-void const methods return values that callers should not ignore. Add `[[nodiscard]]`:

    - `DockConfiguration::getApplications()` (dockconfiguration.h:45)
    - `DockConfiguration::isEmpty()` (dockconfiguration.h:47)
    - `DockConfiguration::getApplicationCount()` (dockconfiguration.h:53)
    - `DockConfiguration::getDockName()` (dockconfiguration.h:57)
    - `DockConfiguration::getFileName()` (dockconfiguration.h:58)
    - `DockConfiguration::getSlitLocation()` (dockconfiguration.h:59)
    - `DockConfiguration::isModified()` (dockconfiguration.h:65)
    - `DockConfiguration::isValid()` (dockconfiguration.h:66)
    - `DockConfiguration::isValidIndex()` (dockconfiguration.h:83)
    - `DockFileManager::getLastError()` (dockfilemanager.h:37)
    - `DockFileManager::isInMenu()` (dockfilemanager.h:42)
    - `DockFileParser::extractSlitLocation()` (dockfileparser.h:39)
    - `DockFileParser::getLastError()` (dockfileparser.h:40)
    - `DockIconInfo::isDesktopFile()` (dockiconinfo.h:54)
    - `DockIconInfo::isValid()` (dockiconinfo.h:58)
    - `DockIconInfo::toStringList()` (dockiconinfo.h:70)
    - `DockIconManager::getLastError()` (dockiconmanager.h:40)
    - `DockIconManager::generateIconStyle()` (dockiconmanager.h:60)
    - `DockIconManager::getIconSearchPaths()` (dockiconmanager.h:61)

---

### Group I — Trivial one-liners

Safe to batch into one commit without individual review.

10. [x] **Duplicate `option(USE_CLANG ...)` in CMakeLists.txt** — Same root cause as item 1 but the duplication itself is a trivial removal. Apply as part of fixing item 1.

11. [x] **Redundant `-pedantic` flag** — Same root cause as item 2 but removing the duplicate flag is a one-line change. Apply as part of fixing item 2.

---

**Summary:** 5 groups, 11 findings total (Groups E, F, I done — 8 fixed, 3 open). The biggest concern is shell-string interpolation of user-entered commands in generated dock scripts (item 4), which could produce broken or unintended dock executables.

---

### ✅ Group E — Code quality cleanup (DONE)

| # | Item | What changed |
|---|------|-------------|
| 5 | `PickLocation::button` public member | picklocation.h/cpp: made private, added `getSelectedLocation()` getter, updated call site |
| 6 | Unused `DRAG_THRESHOLD` constant | icondragdrophandler.h: removed dead constant |
| 7 | `getIconSearchPaths()` allocation | dockiconmanager.cpp: cached result with `static const` lambda init |

### ✅ Group F — Code style (DONE)

| # | Item | What changed |
|---|------|-------------|
| 8 | snake_case local variables | mainwindow.cpp: renamed to camelCase |
| 9 | Missing `[[nodiscard]]` on const getters | 5 headers: annotated 19 const getters across DockConfiguration, DockFileManager, DockFileParser, DockIconInfo, DockIconManager |

### ✅ Group I — Trivial one-liners (DONE)

| # | Item | What changed |
|---|------|-------------|
| 10 | Duplicate `option(USE_CLANG)` | CMakeLists.txt: removed first occurrence |
| 11 | Redundant `-pedantic` flag | CMakeLists.txt: removed duplicate flag |

**Removed during validation:**
- `pkill -x` finding — intentional, user wants to kill all wmalauncher
- `runCommandQuiet()` timeout — `sed` on local files unlikely to block
- Static QRegularExpression init order — safe with string literals
- Include ordering — no project convention specified
- Group C (QThread::msleep + zless) — user not concerned about these
