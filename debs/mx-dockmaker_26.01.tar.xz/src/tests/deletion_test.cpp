/**********************************************************************
 *  deletion_test.cpp
 **********************************************************************
 * Copyright (C) 2020-2025 MX Authors
 *
 * Authors: Adrian
 *          MX Linux <http://mxlinux.org>
 *
 * This is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package. If not, see <http://www.gnu.org/licenses/>.
 **********************************************************************/

#include <QtTest/QtTest>

#include "dockconfiguration.h"

class DeletionTest : public QObject
{
    Q_OBJECT

private slots:
    void removeSingleApplicationDoesNotCrash();
};

void DeletionTest::removeSingleApplicationDoesNotCrash()
{
    DockConfiguration config;
    DockIconInfo info;
    info.appName = QStringLiteral("app.desktop");
    QVERIFY(config.addApplication(info) >= 0);
    QCOMPARE(config.getApplicationCount(), 1);

    QVERIFY(config.removeApplication(0));
    QCOMPARE(config.getApplicationCount(), 0);
    QVERIFY(config.isEmpty());
}

QTEST_GUILESS_MAIN(DeletionTest)
#include "deletion_test.moc"
