<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.0" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Program_Name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="29"/>
        <source>Usage</source>
        <translation>Usage</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="106"/>
        <source>Dock Preview</source>
        <translation>Dock Preview</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="118"/>
        <source>Add New Application</source>
        <translation>Add New Application</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>Command</source>
        <translation>Command</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="301"/>
        <source>Add application</source>
        <translation>Add application</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="393"/>
        <source>Delete this application</source>
        <translation>Delete this application</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="124"/>
        <source>Border</source>
        <translation>Border</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="154"/>
        <source>Size</source>
        <translation>Size</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="161"/>
        <source>Background</source>
        <translation>Background</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="379"/>
        <source>Back</source>
        <translation>Back</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="184"/>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="216"/>
        <location filename="mainwindow.cpp" line="708"/>
        <location filename="mainwindow.cpp" line="735"/>
        <source>Select icon...</source>
        <translation>Select icon...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="229"/>
        <location filename="mainwindow.cpp" line="82"/>
        <location filename="mainwindow.cpp" line="582"/>
        <location filename="mainwindow.cpp" line="711"/>
        <source>Select...</source>
        <translation>Select...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="315"/>
        <source>Move right</source>
        <translation>Move right</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="328"/>
        <source>Move left</source>
        <translation>Move left</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="439"/>
        <source>Display help </source>
        <translation>Display help </translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="442"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="449"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="478"/>
        <source>About this application</source>
        <translation>About this application</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="481"/>
        <source>About...</source>
        <translation>About...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="488"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="520"/>
        <source>Quit application</source>
        <translation>Quit application</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="523"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="530"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="571"/>
        <source>Save</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="103"/>
        <source>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</source>
        <translation>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="126"/>
        <location filename="mainwindow.cpp" line="590"/>
        <source>black</source>
        <translation>black</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="127"/>
        <location filename="mainwindow.cpp" line="591"/>
        <source>white</source>
        <translation>white</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="137"/>
        <source>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</source>
        <translation>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="139"/>
        <source>Operation mode</source>
        <translation>Operation mode</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="140"/>
        <source>&amp;Close</source>
        <translation>&amp;Close</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="141"/>
        <source>&amp;Move</source>
        <translation>&amp;Move</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="142"/>
        <location filename="mainwindow.cpp" line="295"/>
        <source>&amp;Delete</source>
        <translation>&amp;Delete</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="143"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edit</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="144"/>
        <source>C&amp;reate</source>
        <translation>C&amp;reate</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="220"/>
        <source>Dock name</source>
        <translation>Dock name</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="221"/>
        <source>Enter the name to show in the Menu:</source>
        <translation>Enter the name to show in the Menu:</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <source>Select dock to delete</source>
        <translation>Select dock to delete</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="294"/>
        <source>Confirmation</source>
        <translation>Confirmation</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="295"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Are you sure you want to delete %1?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="295"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancel</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="353"/>
        <source>Next</source>
        <translation>Next</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="320"/>
        <source>Select dock to move</source>
        <translation>Select dock to move</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="320"/>
        <location filename="mainwindow.cpp" line="454"/>
        <location filename="mainwindow.cpp" line="657"/>
        <source>Dock Files (*.mxdk);;All Files (*.*)</source>
        <translation>Dock Files (*.mxdk);;All Files (*.*)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="330"/>
        <location filename="mainwindow.cpp" line="351"/>
        <location filename="mainwindow.cpp" line="666"/>
        <source>Could not open file</source>
        <translation>Could not open file</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="453"/>
        <source>Overwrite?</source>
        <translation>Overwrite?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="453"/>
        <source>Do you want to overwrite the dock file?</source>
        <translation>Do you want to overwrite the dock file?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="454"/>
        <source>Save file</source>
        <translation>Save file</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="492"/>
        <source>Dock saved</source>
        <translation>Dock saved</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="492"/>
        <source>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</source>
        <translation>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="511"/>
        <source>About %1</source>
        <translation>About %1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="513"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="514"/>
        <source>Description goes here</source>
        <translation>Description goes here</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="516"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="517"/>
        <source>%1 License</source>
        <translation>%1 License</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="526"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <source>Select .desktop file</source>
        <translation>Select .desktop file</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <source>Desktop Files (*.desktop)</source>
        <translation>Desktop Files (*.desktop)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="657"/>
        <source>Select a dock file</source>
        <translation>Select a dock file</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="660"/>
        <source>No file selected</source>
        <translation>No file selected</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="660"/>
        <source>You haven't selected any dock file to edit.
Creating a new dock instead.</source>
        <translation>You haven&apos;t selected any dock file to edit.
Creating a new dock instead.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="666"/>
        <source>Could not open selected file.
Creating a new dock instead.</source>
        <translation>Could not open selected file.
Creating a new dock instead.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="675"/>
        <source>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</source>
        <translation>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="719"/>
        <source>Select icon</source>
        <translation>Select icon</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="719"/>
        <source>Icons (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Icons (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
</context>
<context>
    <name>PickLocation</name>
    <message>
        <location filename="picklocation.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="23"/>
        <source>Dock Location</source>
        <translation>Dock Location</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="29"/>
        <source>TopCenter</source>
        <translation>TopCenter</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="45"/>
        <source>BottomLeft</source>
        <translation>BottomLeft</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="61"/>
        <source>BottomCenter</source>
        <translation>BottomCenter</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="80"/>
        <source>TopLeft</source>
        <translation>TopLeft</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="96"/>
        <source>TopRight</source>
        <translation>TopRight</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="112"/>
        <source>LeftCenter</source>
        <translation>LeftCenter</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="128"/>
        <source>RightCenter</source>
        <translation>RightCenter</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="144"/>
        <source>BottomRight</source>
        <translation>BottomRight</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="160"/>
        <source>RightTop</source>
        <translation>RightTop</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="173"/>
        <source>LeftTop</source>
        <translation>LeftTop</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="189"/>
        <source>LeftBottom</source>
        <translation>LeftBottom</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="205"/>
        <source>RightBottom</source>
        <translation>RightBottom</translation>
    </message>
    <message>
        <location filename="picklocation.cpp" line="9"/>
        <source>Select dock location</source>
        <translation>Select dock location</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="about.cpp" line="32"/>
        <source>License</source>
        <translation>License</translation>
    </message>
    <message>
        <location filename="about.cpp" line="33"/>
        <location filename="about.cpp" line="43"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="about.cpp" line="34"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="about.cpp" line="51"/>
        <source>&amp;Close</source>
        <translation>&amp;Close</translation>
    </message>
    <message>
        <location filename="main.cpp" line="57"/>
        <source>Error</source>
        <translation>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="58"/>
        <source>You must run this program as normal user.</source>
        <translation>You must run this program as normal user.</translation>
    </message>
</context>
</TS>